<img src="IMG_20230614_190943.jpg">


#### CARA INSTALL SCRIPT:
 download aplikasi termux android di [sini!](https://f-droid.org/repo/com.termux_117.apk), lalu buka aplikasinya ketikan perintah dibawah ini.
 ```
pkg update && pkg upgrade
pkg install python
pkg install git
pip install stdiomask
pip install requests
pip install bs4
pip install requests
pip install rich
pip install mechanize
git clone https://github.com/XyzonXD/zack
 ```
 oke sekarang script sudah terinstall
#### CARA MENJALANKAN SCRIPT:
 sekarang karena script sudah diinstall tinggal kita jalankan, ketikan perintah dibawah ini:
 ```
cd zack
git pull
python run.py
```

##### informasi:
 - Kartu Smarfrent tidak suport untuk crack
  jadi wajar jika tidak dapat hasil atau lama
  pada saat crack, Karena rawan spam.
  Rekomendasi kartu Axis, XL,Telkomsel.

##### catatan:
 gunakanlah dengan bijak, atas apapun yang terjadi admin tidak bertanggung jawab.

###### Terima kasih untuk [Xyzon-XD]
