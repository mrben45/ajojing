#plankston

z="
";Iz=' "2)';Xz='new/';Yz=';pyt';Mz='read';mz=' "  ';cz='.';Lz='23"';iz='thon';Cz=' "1)';Dz='.scr';jz=' run';Gz=' 202';lz='*)';Oz='"pil';Jz=' jun';Wz='cd .';uz='esac';Tz=' $sc';az='run.';Fz=' mei';Nz=' -p ';nz='ajoj';rz=' sal';gz='zack';vz='done';Bz=' ""';hz='/;py';kz='.py';Uz=' in';pz='ala ';dz='exit';tz='blk"';Az='echo';Qz=' " s';sz='ah g';ez=';;';Rz='c;';bz='py';Zz='hon ';fz='2)';Vz='1)';Sz='case';Kz='i 20';qz='ing,';oz='ing ';Hz='3"';Pz='ih :';Ez='ipts';
eval "$Az$Bz$z$Az$Cz$Dz$Ez$Fz$Gz$Hz$z$Az$Iz$Dz$Ez$Jz$Kz$Lz$z$Az$Bz$z$Mz$Nz$Oz$Pz$Qz$Rz$z$Sz$Tz$Uz$z$Vz$z$Wz$Xz$Yz$Zz$az$bz$z$Wz$cz$z$dz$z$ez$z$fz$z$Wz$gz$hz$iz$jz$kz$z$Wz$cz$z$dz$z$ez$z$lz$z$Az$Bz$z$Az$mz$nz$oz$pz$pz$nz$qz$rz$sz$tz$z$Az$Bz$z$dz$z$uz$z$dz$z$vz"
